<?php 
	echo "<pre>";
	print_r($_POST);
	
	
	$name=$_POST['uname'];
	$mob=$_POST['mobile'];
	
	echo "Username:".$name."<br>";
	echo "Mobile:".$mob."<br>";
	
?>