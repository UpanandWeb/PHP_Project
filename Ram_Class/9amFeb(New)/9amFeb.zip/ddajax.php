<html>
	<head>
		<title>Dependency DropDown</title>
	</head>
	<body>
		<h1>Dependency DropDown</h1>
		
		Select State:
		<select id="state">
			<option value="">--Select State--</option>
		</select>
		Select District:
		<select id="dist">
			<option value="">--Select District--</option>
		</select>
	</body>
</html>