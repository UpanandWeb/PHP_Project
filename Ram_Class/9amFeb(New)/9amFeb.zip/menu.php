<style>
.usermenu li
{
	display:inline-block;
	padding:5px 10px;
}
.usermenu li a{
	text-decoration:none;
	color:#fff;
}
.usermenu{
	background:Tomato;
}
</style>
<ul class="usermenu">
		<li><a href="home.php">Profile</a></li>
		<li><a href="edit.php">Edit Prfoile</a></li>
		<li><a href="avatar.php">Upload Aavatar</a></li>
		<li><a href="change_pass.php">Change Password</a></li>
		<li><a href="logout.php">Logout</a></li>
	</ul>