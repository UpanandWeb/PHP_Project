<html>
	<head>
		<title>Session and Cookie</title>
	</head>
	<body>
		<form method="POST" action="p2.php">
			Number1<input type="text" name="num1">
			<input type="submit" value="Go">
		</form>
	
	</body>
</html>