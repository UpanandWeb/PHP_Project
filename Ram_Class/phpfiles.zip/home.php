<?php session_start();
if(isset($_SESSION['logintrue']))
{
	?>
	<h1>Welcome to XXXXXX</h1>
	<a href="logout.php">Logout</a>
	<?php
}
else
{
	header("Location:login.php");
}

?>