<?php 

require("header.php");
require("xyz.php");
require("header.php");






?>