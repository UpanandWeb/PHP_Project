<pre>
<?php 
$arr=[50,60,80,70,40];
echo implode(","$arr);

/*$arr=[50,60,80,70,40];
array_splice($arr,3,0,100);
print_r($arr);
*/
/*
$fa=array_slice($arr,2);
print_r($fa);
// from 2nd position we will get all the elements

$fa=array_slice($arr,0,2);
print_r($fa);
// we can get only two elements from 0th position
*/
/*echo end($arr);//80
echo prev($arr);//70
echo prev($arr);//50
echo current($arr);//50
echo next($arr);//70
*/
/*
$arr=[
	"name"=>"Ram",
	"city"=>"Hyd",
	"state"=>"TS",
];
$fa=array_values($arr);
print_r($fa);
*/
/*$arr=[10,20,30,10,20,50,10,70,80,60,50];
$fa=array_unique($arr);
print_r($fa);*/
/*shuffle($arr);
print_r($arr);*/
/*echo array_key_exists(4,$arr);//1

$arr=[
	"name"=>"Ram",
	"city"=>"Hyd",
	"state"=>"TS",
];
echo array_key_exists("city",$arr);//1
*/


//$fa=array_merge($a1,$a2,$a3);

//print_r($fa);



/*
$arr=array("ram","Ram","Ramu","tam","Tam");
$arr=[
	"name"=>"Ram",
	"city"=>"Hyd",
	"state"=>"TS",
];
$n=count($arr);

for($i=0;$i<$n;$i++)
{
	echo $arr[$i];
	echo "<br>";
}
*/
/*$arr=array(
	"10"=>"Ram",
	"city"=>"Hyderabad",
	100,200,300
);
print_r($arr);
*/

/*$arr=array(
	10,20,30,array(100,200,array(1000,2000,3000)),
);
print_r($arr);
*/



//$names=array(1=>"Ram","PHP","HTML","CSS","JS","jQuery");
/*$names=array(
	14=>"Ram",
	"PHP",
	15=>"HTML",
	"CSS",
	"JS",
	"jQuery"
);
print_r($names);
*/


/*$arr=array(10,20,30,40);
$arr1=array(true,false,10);
$names=array("Ram","Nit","Sam");
print_r($arr1);
print_r($names);*/
?>