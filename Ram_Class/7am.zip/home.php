<?php 
session_start();
//check the seseion availability
if(isset($_SESSION['logintrue']))
{
	$uniid=$_SESSION['logintrue'];
	$con=mysqli_connect("localhost","root","","7am");
	//get the data of loggedin user based on session id and display in html table
	$data=mysqli_query($con,"select *from users where uniid='$uniid'");
	
	$row=mysqli_fetch_assoc($data);
	//print_r($row);
	?>
	<html>
	<head>
		<title>Welcome to <?php echo $row['username']?></title>
		<link href="css/style.css" rel="stylesheet">
	</head>
	<body>
		<ul class="menu">
			<li><a href="home.php">Home</a></li>
			<li><a href="edit.php">Edit Profile</a></li>
			<li><a href="avatar.php">Upload Profile</a></li>
			<li><a href="change_pwd.php">Change Password</a></li>
			<li><a href="logout.php">Logout</a></li>
		</ul>
		<h1>Welcome to <?php echo $row['username']?></h1>
		<table border=1>
			<tr>
				<td></td>
				<td>
					<?php 
					if($row['profile_pic']=="")
					{
						?>
							<img src="images/avatar.png" height="50" width="50">
						<?php
					}
					else
					{
						?>
						<img src="profiles/<?php echo $row['profile_pic']?>" height="50" width="50">
						<a href=''>Remove</a>
						<?php
					}
					?>
				</td>
			</tr>
			<tr>
				<td>Name</td>
				<td><?php echo $row['username']?></td>
			</tr>
			<tr>
				<td>Email</td>
				<td><?php echo $row['email']?></td>
			</tr>
			<tr>
				<td>MObile</td>
				<td><?php echo $row['mobile']?></td>
			</tr>
			<tr>
				<td>DOB</td>
				<td><?php echo $row['dob']?></td>
			</tr>
			<tr>
				<td>State</td>
				<td><?php echo $row['state']?></td>
			</tr>
			<tr>
				<td>DOJ</td>
				<td><?php echo $row['doj']?></td>
			</tr>
		</table>
	</body>
</html>
	<?php
}
else
{
	header("Location:login.php");
}
?>