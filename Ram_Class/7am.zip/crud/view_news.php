<?php include("connect.php")?>
<html>
	<head>
		<title>View News Articles</title>
		<style></style>
	</head>
	<body>
		<h1>View News Articles</h1>
		<ul>
			<li><a href="add_news.php">Add News</a></li>
			<li><a href="view_news.php">View News</a></li>
		</ul>
		
		
		<?php 
		if(isset($_COOKIE['success']))
		{
			echo "<p>".$_COOKIE['success']."</p>";
		}
		
		if(isset($_COOKIE['error']))
		{
			echo "<p>".$_COOKIE['error']."</p>";
		}
		
		
		
		$result=mysqli_query($con,"select *from news");
		if(mysqli_num_rows($result)>0)
		{
			?>
			<table border=1>
			<tr>
				<th>ID</th>
				<th>Category</th>
				<th>Title</th>
				<th>Description</th>
				<th>Image</th>
				<th>Status</th>
				<th>Action</th>
			</tr>
			<?php 
			while($row=mysqli_fetch_assoc($result))
			{
				?>
			<tr>
				<td><?php echo $row['id'];?></td>
				<td><?php echo $row['category'];?></td>
				
				<td><?php echo $row['title'];?></td>
<td><?php echo substr($row['description'],0,100);?>...</td>
				<td>
					<?php 
					if($row['image']!="")
					{
						?>
						<img src='banners/<?php echo $row['image'];?>' height="50" width="50">
						<?php
					}
					else
					{
						?>
						<img src='' height="50" width="50">
						<?php
					}
					?>
				</td>
				<td><?php echo $row['status'];?></td>
				<td>
					<a href='edit_news.php?nid=<?php echo $row['id'];?>'>Edit</a>
					<a href='javascript:void(0)' onclick='deleteRecord(<?php echo $row['id'];?>)'>Delete</a>
				</td>
			</tr>
				<?php
			}
			?>
		</table>
			<?php
		}
		else
		{
			echo "<p>Sorry! No records FOund</p>";
		}
		?>
		
		<script>
		function deleteRecord(id)
		{
			var c=confirm("Do you want to delete?");
			if(c==true)
			{
				window.location="delete_news.php?did="+	;
			}
		}
		</script>
	</body>
</html>