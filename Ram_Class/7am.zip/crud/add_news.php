<?php include("connect.php");?>
<html>
	<head>
		<title>Add News Article</title>
		<style></style>
	</head>
	<body>
		<h1>Add News Article</h1>
		<ul>
			<li><a href="add_news.php">Add News</a></li>
			<li><a href="view_news.php">View News</a></li>
		</ul>
		<?php 
		if(isset($_COOKIE['success']))
		{
			echo "<p>".$_COOKIE['success']."</p>";
		}
		
		if(isset($_POST['submit']))
		{
			$cat=(isset($_POST['cat']))?$_POST['cat']:"";
			$title=(isset($_POST['title']))?$_POST['title']:"";
			$desc=(isset($_POST['desc']))?$_POST['desc']:"";
			if(is_uploaded_file($_FILES['file']['tmp_name']))
			{
				$filename=$_FILES['file']['name'];
				$type=$_FILES['file']['type'];
				$tname=$_FILES['file']['tmp_name'];
				
				$arr=array("image/jpeg","image/png","image/gif","image/jpg");
					
				$str=str_shuffle("abcdefghijklmnopqerstuwxyz");
				$s=substr($str,5,15);
				$newname=$s.$filename;
				
				if(in_array($type,$arr))
				{
					move_uploaded_file($tname,"banners/$newname");
					$filename=$newname;
				}
				else
				{
					echo "<p>Please select a valid image to upload</p>";
				}

			}
			else
			{
				$filename="";
			}
			
			mysqli_query($con,"insert into news(category,title,description,image) values('$cat','$title','$desc','$filename')");
			if(mysqli_affected_rows($con)==1)
			{
				setcookie("success","News Article added successfully",time()+2);
				header("Location:add_news.php");
			}
			else
			{
				if($filename)
				{
					unlink("banners/$newname");
				}
				echo "<p>Sorry Unable to add the article, try again</p>";
			}
			
		}
		?>
		
		
		<form enctype="multipart/form-data" method="POST" action="" onsubmit="return newsValidate()">
			<table>
				<tr>
					<td>Category</td>
					<td>
						<select id="cat" name="cat">
						<option value="">--select category--</option>
						<option value="movies">Movies</option>
						<option value="sports">Sports</option>
						<option value="politics">Politics</option>
						</select>
					</td>
				</tr>
				<tr>
					<td>News Title</td>
					<td><input type="text" name="title" id="title"></td>
				</tr>
				<tr>
					<td>News Description</td>
					<td><textarea cols="40" rows="10" name="desc" id="desc"></textarea></td>
				</tr>
				<tr>
					<td>Upload news <br>banner or Image</td>
					<td><input type="file" name="file" id="file"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" name="submit" value="Add News"></td>
				</tr>
			</table>
		</form>
		<script>
		function newsValidate()
		{
			if(document.getElementById("cat").value=="")
			{
				alert("select category");
				return false;
			}
			if(document.getElementById("title").value=="")
			{
				alert("Please eneter title of the article");
				return false;
			}
		}
		</script>
	</body>
</html>