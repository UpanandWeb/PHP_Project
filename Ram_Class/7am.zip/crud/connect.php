<?php 
$con=mysqli_connect("localhost","root","","7am");
?>