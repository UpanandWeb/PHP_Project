<?php 
if(isset($_REQUEST['key']))
{
	$state=$_REQUEST['key'];
	$con=mysqli_connect("localhost","root","","7am");
	$res=mysqli_query($con,"select district from states where state='$state'");
	if(mysqli_num_rows($res)>0)
	{
		?>
			<option value=''>--select district--</option>
		<?php
		while($row=mysqli_fetch_assoc($res))
		{
			?>
			<option value='<?php echo $row['district']; ?>'><?php echo $row['district']; ?></option>
			<?php
		}
	}
	else
	{
		
	}
}
?>