<?php
$con=mysqli_connect("localhost","root","","7am") 
or die("unable to connect");
$data=mysqli_query($con,"select *from contact");
$row=mysqli_fetch_object($data);
echo "<pre>";
print_r($row);
?>
