<html>
	<head>
		<title>Contact Form</title>
		<!--2nd Step-->
		<style>
			body{
				background:#d3d3d3;
			}
		</style>
	</head>
	<body>
		<h1>Contact Here</h1>
		
		<?php 
		
		if(isset($_COOKIE['success']))
		{
			echo $_COOKIE['success'];
		}
		//4 th step
		if(isset($_POST['submit']))
		{
			//4.1 collect the form data
			$name=$_POST['name'];
			$mail=$_POST['email'];
			$mob=$_POST['mobile'];
			$mess=$_POST['msg'];
			//4.2 connect to DB
			$con=mysqli_connect("localhost","root","","7am");
			//4.3 insert data into a table
			mysqli_query($con,"insert into contact 
			values('','$name','$mail','$mob','$mess',now())");
			echo mysqli_error($con);
			if(mysqli_affected_rows($con)==1)
			{
				setcookie("success","Thanks, we will get back you soon",time()+2);
				header("location:contact.php");
				
			}
			else
			{
				echo "<p>Sorry! Unable to process, 
				try again</p>";
			}
		}
		?>
		
		<form method="POST" action="" 
		onsubmit="return myformValidation()">
			<table>
				<tr>
					<td>Name</td>
					<td><input type="text" name="name" 
					id="name"></td>
				</tr>
				<tr>
					<td>Email</td>
					<td><input type="text" name="email" 
					id="email"></td>
				</tr>
				<tr>
					<td>Mobile</td>
					<td><input type="text" name="mobile" 
					id="mobile"></td>
				</tr>
				<tr>
					<td>Message</td>
		<td><textarea name="msg" id="msg"></textarea></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" name="submit" 
					value="Send"></td>
				</tr>
			</table>
		</form>
		<!--3rd step validation-->
		<script>
		function myformValidation()
		{
			var n=document.getElementById("name").value;
			if(n=="")
			{
				alert("Enter Name");
				return false;
			}
			var e=document.getElementById("email").value;
			if(e=="")
			{
				alert("Enter Email");
				return false;
			}
		}
		</script>		
	</body>
</html>