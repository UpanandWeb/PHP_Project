<html>
	<head>
		<title>Users List</title>
	</head>
	<body>
		<h1>Users List</h1>
		<?php 
		$con=mysqli_connect("localhost",
		"root","","7am");
		$result=mysqli_query($con,
		"select *from contact");
		if(mysqli_num_rows($result)>0)
		{
			?>
			<table>
			<tr>
				<th>Id</th>
				<th>Name</th>
				<th>Email</th>
				<th>Mobile</th>
				<th>Message</th>
				<th>Time</th>
			</tr>
			<?php 
			while($row=mysqli_fetch_object($result))
			{
				?>
				<tr>
					<td><?php echo $row->id;?></td>
					<td><?php echo $row->name;?></td>
					<td><?php echo $row->email;?></td>					
				</tr>
				<?php
			}
			?>
		</table>
			<?php
		}
		else
		{
			echo "<p>Sorry No records Found</p>";
		}
		?>	
	</body>
</html>