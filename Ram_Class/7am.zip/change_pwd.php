<?php session_start();
if(isset($_SESSION['logintrue']))
{
	$uid=$_SESSION['logintrue'];
	$con=mysqli_connect("localhost","root","","7am");
	$data=mysqli_query($con,"select username,password from users where uniid='$uid'");
	$row=mysqli_fetch_assoc($data);
	?>
	<html>
		<head>
			<title><?php echo $row['username']?> | Change Password</title>
			<link href='css/style.css' rel="stylesheet">
		</head>
		<body>
			<ul class="menu">
				<li><a href="home.php">Home</a></li>
				<li><a href="edit.php">Edit Profile</a></li>
				<li><a href="avatar.php">Upload Profile</a></li>
				<li><a href="change_pwd.php">Change Password</a></li>
				<li><a href="logout.php">Logout</a></li>
			</ul>
			<h1>Change Password</h1>
			
			<?php 
			
			if(isset($_COOKIE['success']))
			{
				echo "<p>".$_COOKIE['success']."</p>";
			}
			
			if(isset($_POST['submit']))
			{
				$opwd=$_POST['opwd'];
				$npwd=$_POST['npwd'];
				$cnpwd=$_POST['cnpwd'];
				
				//print_r($row['password']);
				if(password_verify($opwd,$row['password'])==1)
				{
					if($npwd==$cnpwd)
					{
						$npwd=password_hash($npwd,PASSWORD_DEFAULT);
						mysqli_query($con,"update users set password='$npwd' where uniid='$uid'");
						if(mysqli_affected_rows($con))
						{
							setcookie("success","Password updated successfully",time()+2);
							header("location:change_pwd.php");
						}
					}
					else
					{
						echo "<p>New and Confor, new password does not macthed.</p>";
					}
				}
				else
				{
					echo "<p>Old Password does not macthed with DB Password</p>";
				}
			}
			?>
			
			<form method="POST" action="" onsubmit="return pwdValidqation()">
				<table>
					<tr>
						<td>Old Password</td>
						<td><input type="password" name="opwd" id="opwd"></td>
					</tr>
					<tr>
						<td>New Password</td>
						<td><input type="password" name="npwd" id="npwd"></td>
					</tr>
					<tr>
						<td>Confirm New Password</td>
						<td><input type="password" name="cnpwd" id="cnpwd"></td>
					</tr>
					<tr>
						<td></td>
						<td><input type="submit" name="submit" value="Update"></td>
					</tr>
				</table>
			</form>
			<script>
				function pwdValidqation()
				{
					if(document.getElementById("opwd").value=="")
					{
						alert("Enter Old Password");
						return false;
					}
					if(document.getElementById("npwd").value=="")
					{
						alert("Enter New Password");
						return false;
					}
					if(document.getElementById("cnpwd").value=="")
					{
						alert("Enter Confirm New Password");
						return false;
					}
				}
			</script>
		</body>
	</html>
	<?php
}
else
{
	header("Location:login.php");
}
?>