<html>
	<head>
		<title>File Uploading</title>
	</head>
	<body>
		<h1>File Uploading</h1>
		
		<?php 
		if(isset($_POST['upload']))
		{
			//echo "<pre>";
			//print_r($_FILES);
			if(is_uploaded_file($_FILES['image']['tmp_name']))
			{
				$filename=$_FILES['image']['name'];
				$size=$_FILES['image']['size'];
				$type=$_FILES['image']['type'];
				$tname=$_FILES['image']['tmp_name'];
				$error=$_FILES['image']['error'];
				
				$status=move_uploaded_file($tname,"uploads/$filename");
				if($status==1)
				{
					echo "<p>File Uploaded successfully</p>";
				}
			}
			else
			{
				echo "<p>Please select a file to upload</p>";
			}
			
		}
		?>
		
		
		
		
		<form method="POST" action="" enctype="multipart/form-data">
			
			Select a file to upload:
			<input type="file" name="image">
			<br>
			<input type="submit" name="upload" value="Submit">
		</form>
		
		<?php 
		$dp=opendir("uploads");
		while($file=readdir($dp))
		{
			if(!($file=="." || $file==".."))
			{
				?>
				<img src="uploads/<?php echo $file;?>" 
				height="50" width="50">
				<?php
			}
		}

		?>
	</body>
</html>