<?php 
if(isset($_REQUEST['uid']))
{
	if($_REQUEST['uid']!="")
	{
		$uid=$_REQUEST['uid'];
		$con=mysqli_connect("localhost","root","","7am");
		$res=mysqli_query($con,"select username from users where uniid='$uid'");
		if(mysqli_num_rows($res)==1)
		{
			?>
			<html>
				<head>
					<title>Reset Password</title>
					<style></style>
				</head>
				<body>
					<h1>Reset Password</h1>
		<?php 
		if(isset($_POST['update']))
		{
			$pwd=$_POST['pwd'];
			$cpwd=$_POST['cpwd'];
			if($pwd==$cpwd)
			{
				$pwd=password_hash($pwd,PASSWORD_DEFAULT);
				mysqli_query($con,"update users set password='$pwd' where uniid='$uid'");
				if(mysqli_affected_rows($con))
				{
					setcookie("success","Password updated successfully. please login",time()+2);
					header("location:login.php");
				}
				else
				{
					echo "<p>Sorry! Unable to update password try again</p>";
				}
			}
			else
			{
				echo "<p>Passwords does not matched</p>";
			}
		}
		?>	
				
		<form method="POST" action="" onsubmit="return resetValidate()">
			<table>
				<tr>
					<td>New Password</td>
					<td><input type="password" name="pwd" id="pwd"></td>
				</tr>
				<tr>
					<td>Confirm Password</td>
					<td><input type="password" name="cpwd" id="cpwd"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" name="update" value="Update"></td>
				</tr>
			</table>
		</form>
		<script>
			function resetValidate()
			{
				/*Passsword validation*/
			if(document.getElementById("pwd").value=="")
			{
				alert("Enter Password");
				return false;
			}
			if(document.getElementById("cpwd").value=="")
			{
				alert("Enter Confirm Password");
				return false;
			}
			if(document.getElementById("pwd").value != document.getElementById("cpwd").value)
			{
				alert("Passwords does not matched");
				return false;
			}
			}
		</script>
				</body>
			</html>
			<?php
		}
		else
		{
			echo "<p>Please check reset password link,somthing went wrong</p>";
		}
	}
	else
	{
		exit("Sorry again");
	}
}
else
{
	exit("Sorry");
}
?>