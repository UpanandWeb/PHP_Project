-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 11, 2019 at 05:40 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `7am`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `message` text NOT NULL,
  `time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `mobile`, `message`, `time`) VALUES
(1, 'Ram', 'ram@mail.com', 423423423, 'Hello', '2019-09-26 04:12:19'),
(2, 'test', 'test@mail.com', 123456987, 'welcome', '2019-09-26 11:43:34'),
(3, 'nit', 'nit@mail.com', 23423423, 'Nit tech', '2019-09-26 10:11:08'),
(4, 'rama', 'rama@mail.com', 23423423, 'test', '2019-09-26 18:51:44'),
(5, 'ram12', 'rambabburi@gmail.com', 9767676767, 'helloo123', '0000-00-00 00:00:00'),
(6, 'ramdfgdfgdfgdf', 'nit@mail.com', 6767676767, 'fg', '2020-04-01 23:07:32'),
(7, 'ram', 'nit@mail.com', 9767676767, 'asd', '2020-04-01 23:09:30'),
(8, 'ram', 'nit@mail.com', 9767676767, 'asd', '2020-04-01 23:10:00'),
(9, 'ravi', 'rambabburi@gmail.com', 9767676767, 'sdf', '2020-04-01 23:11:18'),
(10, 'ram', 'rambabburi@gmail.com', 9767676767, 'adasdsa', '2019-09-30 07:47:41'),
(11, 'ram', 'rambabburi@gmail.com', 9767676767, 'adasdsa', '2019-09-30 07:47:54'),
(12, 'ram', 'rambabburi@gmail.com', 9767676767, 'dgdf', '2019-09-30 07:48:56'),
(13, 'ram', 'rambabburi@gmail.com', 9767676767, 'dgdf', '2019-09-30 07:49:10'),
(14, 'ram', 'rambabburi@gmail.com', 9767676767, 'dgdf', '2019-09-30 07:49:17'),
(15, 'test', 'test@mail.com', 5424234, 'cg', '2019-09-30 07:50:52'),
(16, 'ram', 'rambabburi@gmail.com', 9767676767, 'asd', '2019-09-30 07:54:06');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `category` varchar(250) NOT NULL,
  `title` varchar(250) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(250) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `status` varchar(10) NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `category`, `title`, `description`, `image`, `date`, `status`) VALUES
(4, 'movies', 'Kashmir saw 330 stirs since repeal of Article 370', 'Hero MotoCorp will soon launch Indiaâ€™s first BS6-compliant motorcycle, the Splendor iSmart. Now, we have got our hands on official RTO documents which reveal new information about the upcoming motorcycle. \r\n\r\nAccording to the document, the upcoming Splendor iSmart will be powered by a 113.2cc motor instead of the 109.15cc mill which powers the current BS4-compliant model. Even though there has been a slight increment in cubic capacity, the power hasnâ€™t gone up. Instead, the updated fuel-injected motor now churns out 9.1PS, which is 0.4PS less compared to the current model. ', 'dczmkseqioufyebdc-Cover-rtj9ojl9ehu7jeoc1thqos8b67-20190926015153.Medi.jpeg', '2019-10-12 08:40:14', 'active'),
(5, 'movies', 'Kashmir saw 330 stirs since repeal of Article 370', 'Hero MotoCorp will soon launch Indiaâ€™s first BS6-compliant motorcycle, the Splendor iSmart. Now, we have got our hands on official RTO documents which reveal new information about the upcoming motorcycle. \r\n\r\nAccording to the document, the upcoming Splendor iSmart will be powered by a 113.2cc motor instead of the 109.15cc mill which powers the current BS4-compliant model. Even though there has been a slight increment in cubic capacity, the power hasnâ€™t gone up. Instead, the updated fuel-injected motor now churns out 9.1PS, which is 0.4PS less compared to the current model. ', 'dczmkseqioufyebdc-Cover-rtj9ojl9ehu7jeoc1thqos8b67-20190926015153.Medi.jpeg', '2019-10-12 08:40:14', 'active'),
(6, 'sports', 'ertertret', 'erterterterte', '', '2019-10-11 18:13:47', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE `states` (
  `id` int(11) NOT NULL,
  `state` varchar(100) NOT NULL,
  `district` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `state`, `district`) VALUES
(1, 'Andhrapradesh', 'Prakasam'),
(2, 'Andhrapradesh', 'Krishna'),
(3, 'Andhrapradesh', 'Nellore'),
(4, 'Andhrapradesh', 'Vizag'),
(5, 'Telangana', 'Hyderabad'),
(6, 'Telangana', 'Nalgonda'),
(7, 'Telangana', 'Khammam'),
(8, 'Telangana', 'Warangal'),
(9, 'Maharastra', 'Nasik'),
(10, 'Maharastra', 'Pune'),
(11, 'Maharastra', 'Latur'),
(12, 'Maharastra', 'Nagpur'),
(13, 'Uttarapradesh', 'Varanasi'),
(14, 'Uttarapradesh', 'Lucknow'),
(15, 'Uttarapradesh', 'Kanpur'),
(16, 'Uttarapradesh', 'Ghorakpur'),
(17, 'Bihar', 'Nalanda'),
(18, 'Bihar', 'Patna'),
(19, 'Bihar', 'Sivan'),
(20, 'Bihar', 'Gaya'),
(21, 'West Bengal', 'Kolkata'),
(22, 'West Bengal', 'Burdwan'),
(23, 'West Bengal', 'Duragpur'),
(24, 'West Bengal', 'Howrah'),
(25, 'Madhyapradesh', 'Indore'),
(26, 'Madhyapradesh', 'Bhopal'),
(27, 'Madhyapradesh', 'Reewa'),
(28, 'Madhyapradesh', 'Satna'),
(29, 'Chhattisgarh', 'Raipur'),
(30, 'Chhattisgarh', 'Bilaspur'),
(31, 'Chhattisgarh', 'Korba'),
(32, 'Chhattisgarh', 'Bhilai'),
(33, 'Odisha', 'Bhuvaneswar'),
(34, 'Odisha', 'Cuttack'),
(35, 'Odisha', 'Puri'),
(36, 'Odisha', 'Khurda');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(10) NOT NULL,
  `state` varchar(50) NOT NULL,
  `terms` varchar(10) NOT NULL,
  `doj` datetime NOT NULL DEFAULT current_timestamp(),
  `status` varchar(20) NOT NULL DEFAULT 'inactive',
  `ip` varchar(30) NOT NULL,
  `profile_pic` varchar(250) NOT NULL,
  `uniid` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `mobile`, `dob`, `gender`, `state`, `terms`, `doj`, `status`, `ip`, `profile_pic`, `uniid`) VALUES
(1, 'Ram Babburi', 'rambabburi@gmail.com', '$2y$10$y/30Bb4WuSgAeE2czjLfauX2OoedBIRia62dfztU6XRn90F03R/gu', 7897897890, '1987-07-25', 'male', 'Andhrapradesh', 'yes', '2019-10-01 12:04:25', 'active', '::1', 'uergmjlhdzsfqnyhello_main.jpg', 'b009ccb41e48e0497f0f3ab1a61e85d7'),
(2, 'hello', 'hello@mail.com', '$2y$10$b7mgh80uzLoLg9qTb2WZDOup6ksqZeg38waXtZDcZxe7P.FBeMQEi', 9767676767, '1999-05-04', 'male', 'Andhrapradesh', 'yes', '2019-10-01 12:10:14', 'inactive', '::1', '', '1b3de70b72b0f6fe665337f8d0b236a0'),
(3, 'Rasm', 'nit@mail.com', '$2y$10$CAaDTIdB8SNpyIYcD8JJgeUcu56VEBxu0FF4BA8baymHBxLb4JP3u', 9885776740, '0000-00-00', 'female', 'Andhrapradesh', 'yes', '2019-10-01 12:24:00', 'inactive', '::1', '', '3ae4aa96e88e9846611e422e06758249'),
(4, 'Ramu Babburi', 'ravi@mail.com', '$2y$10$.0mgWgE4VqDLwBF9pFsxAu5s12aEjuraj8MWbyeJhsOWfYuLRTr4q', 9767676767, '0000-00-00', 'male', 'Andhrapradesh', 'yes', '2019-10-01 12:24:42', 'active', '::1', '', '2686674bd15e50f35b25252922753f0f'),
(6, 'Siva Kumar', 'siva@mail.com', '$2y$10$.cqNov5BOZKb3bM7DWTMFu2jIef1yQelsfr5ZcvRTiYpveDX4fGoC', 9767676767, '1999-05-04', 'male', 'Andhrapradesh', 'yes', '2019-10-01 12:49:43', 'active', '::1', 'uzyrgiclfeksmtbmaxresdefault.jpg', '040df1e029ea8f4daa39dce2b74cde01');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `uniid` (`uniid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `states`
--
ALTER TABLE `states`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
