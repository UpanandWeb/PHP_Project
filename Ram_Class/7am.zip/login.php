<?php 
ob_start();
session_start(); ?>
<html>
	<head>
		<title>Login Here</title>
		<style></style>
	</head>
	<body>
		<h1>Login Here</h1>
		
		<?php 
		if(isset($_COOKIE['success']))
		{
			echo "<p>".$_COOKIE['success']."</p>";
		}
		
		if(isset($_POST['login']))
		{
			$email=(isset($_POST['email']))?$_POST['email']:"";
			
			$pwd=(isset($_POST['pwd']))?$_POST['pwd']:"";
			
			$con=mysqli_connect("localhost","root","","7am");
			$data=mysqli_query($con,"select username,password,status,uniid from users where email='$email'");
			if(mysqli_num_rows($data)==1)
			{
				$row=mysqli_fetch_assoc($data);
				if(password_verify($pwd,$row['password'])==1)
				{
					if($row['status']=="active")
					{
						$_SESSION["logintrue"]=$row['uniid'];
						header("Location:home.php");
					}
					else
					{
						echo "<p>Please activate your account</p>";
					}
				}
				else
				{
					echo "<p>Password does not matched</p>";
				}
			}
			else
			{
				echo "<p>Sorry! Email does not exists</p>";
			}
		}
		
		?>
		
		<form method="POST" action="" onsubmit="return loginValidate()">
			<table>
				<tr>
					<td>Email</td>
					<td><input type="text" name="email" id="email"></td>
				</tr>
				<tr>
					<td>Password</td>
					<td><input type="password" name="pwd" id="pwd"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" name="login" value="Login"><a href="forgot.php">Forgot Password?</a></td>
				</tr>
			</table>
		</form>
		<script>
		function loginValidate()
		{
			/*Email validation*/
			if(document.getElementById("email").value=="")
			{
				alert("Enter Email");
				return false;
			}
			else
			{
				var mail=document.getElementById("email").value;
				var re = /\S+@\S+\.\S+/;
				if(!re.test(mail))
				{
					alert("Enter Valid Email");
					return false;
				}
			}
			if(document.getElementById("pwd").value=="")
			{
				alert("Enter Password");
				return false;
			}
		}
		</script>
	</body>
</html>
<?php ob_end_flush();?>