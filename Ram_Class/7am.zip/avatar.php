<?php 
session_start();
if(isset($_SESSION['logintrue']))
{
	$uniid=$_SESSION['logintrue'];
	$con=mysqli_connect("localhost","root","","7am");
	$data=mysqli_query($con,"select username from users where uniid='$uniid'");
	$row=mysqli_fetch_assoc($data);
	?>
	<html>
		<head>
			<title><?php echo $row['username']?> | Upload Profile</title>
			<link href="css/style.css" rel="stylesheet">
		</head>
		<body>
			<ul class="menu">
			<li><a href="home.php">Home</a></li>
			<li><a href="edit.php">Edit Profile</a></li>
			<li><a href="avatar.php">Upload Profile</a></li>
			<li><a href="change_pwd.php">Change Password</a></li>
			<li><a href="logout.php">Logout</a></li>
		</ul>
			<h1>Upload Profile</h1>
			<?php 
			if(isset($_COOKIE['success']))
			{
				echo "<p>".$_COOKIE['success']."</p>";
			}
			
			if(isset($_POST['upload']))
			{
				if(is_uploaded_file($_FILES['image']['tmp_name']))
				{
					$filename=$_FILES['image']['name'];
					$type=$_FILES['image']['type'];
					$tname=$_FILES['image']['tmp_name'];
					
					$arr=array("image/jpeg","image/png","image/gif","image/jpg");
					
					$str=str_shuffle("abcdefghijklmnopqerstuwxyz");
					$s=substr($str,5,15);
					$newname=$s.$filename;
					
					if(in_array($type,$arr)==1)
					{
						if(move_uploaded_file($tname,"profiles/$newname"))
						{
							mysqli_query($con,"update users set profile_pic='$newname' where uniid='$uniid'");
							if(mysqli_affected_rows($con))
							{
								setcookie("success","Profile uploaded successfully",time()+2);
								header("location:avatar.php");
							}
						}
						else
						{
							echo "<p>Sorry, unable to upload. try again</p>";
						}
						
					}
					else
					{
						echo "<p>Please select a valid image to upload</p>";
					}
				}
				else
				{
					echo "<p>Please select a file to upload</p>";
				}
			}
			?>
			
			
			<form method="POST" action="" enctype="multipart/form-data">
				Select an image to upload:
				<input type="file" name="image">
				<br><br>
				<input type="submit" name="upload" value="Upload">
			</form>
		</body>
	</html>
	<?php
	
	
	
}
else
{
	header("location:login.php");
}

?>