<?php 
if(isset($_GET['key']))
{
	// get the uniid from URL
	$uniid=$_GET['key'];
	$con=mysqli_connect("localhost","root","","7am");
	//check the uniid is available in table or not
	$data=mysqli_query($con,"select status,uniid from users where uniid='$uniid'");
	if(mysqli_num_rows($data)==1)
	{
		
		$row=mysqli_fetch_assoc($data);
		//check the status. if status is inactive write update query to make active. if status is laready active display a message already activated
		if($row['status']=="inactive")
		{
			mysqli_query($con,"update users set status='active' where uniid='$uniid'");
			if(mysqli_affected_rows($con))
			{
				echo "<P>Account Activated Successfully</p>";
			}
		}
		else
		{
			echo "<p>Your account already activated</p>";
		}
	}
	else
	{
		echo "<p>Sorry! Unable to find your account</p>";
	}
	
}
else
{
	echo "Sorry";
}

?>