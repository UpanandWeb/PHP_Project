<?php ob_start();
session_start();
if(isset($_SESSION['logintrue']))
{
	$uid=$_SESSION['logintrue'];
	$con=mysqli_connect("localhost","root","","7am");
	$data=mysqli_query($con,"select username,mobile,state,dob from users where uniid='$uid'");
	$row=mysqli_fetch_assoc($data);
	//print_r($row);
?>
<html>
	<head>
		<title>Ram | Edit Profile</title>
		<style></style>
		<link href="css/style.css" rel="stylesheet">
	</head>
	<body>
		<ul class="menu">
			<li><a href="home.php">Home</a></li>
			<li><a href="edit.php">Edit Profile</a></li>
			<li><a href="avatar.php">Upload Profile</a></li>
			<li><a href="change_pwd.php">Change Password</a></li>
			<li><a href="logout.php">Logout</a></li>
		</ul>
		<h1>Edit Profile</h1>
		
		<?php 
		if(isset($_COOKIE['success']))
		{
			echo "<p class='success'>".$_COOKIE['success']."</p>";
		}
		if(isset($_POST['update']))
		{
			$uname=(isset($_POST['uname']))?$_POST['uname']:"";			
			$mobile=(isset($_POST['mobile']))?$_POST['mobile']:"";			
			$dob=(isset($_POST['dob']))?$_POST['dob']:"";			
			$state=(isset($_POST['state']))?$_POST['state']:"";			
			
			mysqli_query($con,"update users set username='$uname',mobile='$mobile',dob='$dob', state='$state' where uniid='$uid'");
			if(mysqli_affected_rows($con)==1)
			{
				setcookie("success","Profile Updated successfully",time()+2);
				header("Location:edit.php");
			}
			else
			{
				echo "<p>Unable to update. Try again</p>";
				echo mysqli_error($con);
			}
			
		}
		?>
		
		<form method="POST" action="" onsubmit="return validate()">
		<table class="table">
			<tr>
				<td>Username*</td>
				<td><input type="text" name="uname" id="uname" value="<?php echo $row['username'];?>"></td>
			</tr>
			
			<tr>
				<td>Mobile</td>
				<td><input type="text" name="mobile" id="mobile" value="<?php echo $row['mobile'];?>"></td>
			</tr>
			
			<tr>
				<td>DOB</td>
				<td><input type="text" name="dob" id="dob" placeholder="2005-05-25" value="<?php echo $row['dob'];?>"></td>
			</tr>
			
			<tr>
				<td>State</td>
				<td>
				<select id="state" name="state">
				<option value="">--select state--</option>
<option <?php if($row['state']=="Andhrapradesh")echo "selected";?> value="Andhrapradesh">Andhrapradesh</option>
<option <?php if($row['state']=="Telangana")echo "selected";?> value="Telangana">Telangana</option>
				</select>
				</td>
			</tr>
			
			
			<tr>
				<td></td>
				<td><input type="submit" name="update"  value="Update"></td>
			</tr>
			
		</table>
		</form>
		<script>
		function validate()
		{
			/*Username validation*/
			if(document.getElementById("uname").value=="")
			{
				alert("Enter Username");
				return false;
			}
			else
			{
				if(document.getElementById("uname").value.length <= 3)
				{
					alert("Enter atleaset 4 chars");
					return false;
				}
				
			}
			
			
			
			/*Mobile Validation*/
			if(document.getElementById("mobile").value=="")
			{
				alert("Enter Mobile");
				return false;
			}
			else
			{
				var mob=document.getElementById("mobile").value;
				var pat=/^[0]?[789]\d{9}$/;
				if(!pat.test(mob))
				{
					alert("Enter a 10 digit valid mobile number");
					return false;
				}
			}
			
		}
		</script>
		
	</body>
</html>
<?php 
}
else
{
	header("Location:login.php");
}

ob_end_flush();?>