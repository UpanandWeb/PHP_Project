<?php ob_start();?>
<html>
	<head>
		<title>Register Form</title>
		<style></style>
	</head>
	<body>
		<h1>Register Here</h1>
		
		<?php 
		//4th step
		if(isset($_COOKIE['success']))
		{
			echo "<p>".$_COOKIE['sucess']."</p>";
		}
		if(isset($_COOKIE['error']))
		{
			echo "<p>".$_COOKIE['error']."</p>";
		}
		if(isset($_POST['register']))
		{
			$uname=(isset($_POST['uname']))?$_POST['uname']:"";			
			$email=(isset($_POST['email']))?$_POST['email']:"";			
			$pass=(isset($_POST['pwd']))?$_POST['pwd']:"";			
			$mobile=(isset($_POST['mobile']))?$_POST['mobile']:"";			
			$dob=(isset($_POST['dob']))?$_POST['dob']:"";			
			$gender=(isset($_POST['gender']))?$_POST['gender']:"";			
			$state=(isset($_POST['state']))?$_POST['state']:"";			
			$tnc=(isset($_POST['terms']))?$_POST['terms']:"";			
			$ip=$_SERVER['REMOTE_ADDR'];
			$uniid=md5(str_shuffle($uname.$email.$mobile.$dob));
			
			$pass=password_hash($pass,PASSWORD_DEFAULT);
			
			
			//connect to DB
			$con=mysqli_connect("localhost","root","","7am");
			
			//insert data into table
			$query="insert into users(username,email,password,mobile,dob,gender,state,terms,ip,uniid) values('$uname','$email','$pass','$mobile','$dob','$gender','$state','$tnc','$ip','$uniid')";
			mysqli_query($con,$query);
			echo mysqli_error($con);
			if(mysqli_affected_rows($con)==1)
			{
				$to=$email;
				$subject="Account Activation Link-GoPHP";
				$message="Hi ".$uname.",<br><br>Thanks for creating an account with us. Please click the below link to activate your account<br><br>
				<a href='http://localhost:100/7am/activate.php?key=".$uniid."' target='_blank'>Activate Now</a><br><br>Thanks><br>Team";
				$headers="Content-Type:text/html";
				if(mail($to,$subject,$message,$headers))
				{
					setcookie("success","Account created successfully. Please activate your account",time()+2);
					header("Location:register.php");
				}
				else
				{
					setcookie("error","Account created successfully. Unbale to activation link, contact admin",time()+2);
					header("Location:register.php");
				}
				
			}
			else
			{
				echo mysqli_error($con);
				echo "<p>Sorry! Unable to insert</p>";
			}
			
		}
		?>
		
		<form method="POST" action="" onsubmit="return validate()">
		<table class="table">
			<tr>
				<td>Username*</td>
				<td><input type="text" name="uname" id="uname"></td>
			</tr>
			<tr>
				<td>Email*</td>
				<td><input type="text" name="email" id="email"></td>
			</tr>
			<tr>
				<td>Password*</td>
				<td><input type="password" name="pwd" id="pwd"></td>
			</tr>
			<tr>
				<td>Confirm Password*</td>
				<td><input type="password" name="cpwd" id="cpwd"></td>
			</tr>
			
			<tr>
				<td>Mobile</td>
				<td><input type="text" name="mobile" id="mobile"></td>
			</tr>
			
			<tr>
				<td>DOB</td>
				<td><input type="text" name="dob" id="dob" placeholder="2005-05-25"></td>
			</tr>
			<tr>
				<td>Gender</td>
				<td>
					<input type="radio" name="gender" value="male">Male
					<input type="radio" name="gender" value="female">Female
				</td>
			</tr>
			<tr>
				<td>State</td>
				<td>
				<select id="state" name="state">
				<option value="">--select state--</option>
				<option value="Andhrapradesh">Andhrapradesh</option>
				<option value="Telangana">Telangana</option>
				</select>
				</td>
			</tr>
			<tr>
				<td></td>
				<td><input type="checkbox" name="terms" id="terms" value="yes">Please accept terms and condition</td>
			</tr>
			
			<tr>
				<td></td>
				<td><input type="submit" name="register"  value="Register"></td>
			</tr>
			
		</table>
		</form>
		<script>
		function validate()
		{
			/*Username validation*/
			if(document.getElementById("uname").value=="")
			{
				alert("Enter Username");
				return false;
			}
			else
			{
				if(document.getElementById("uname").value.length <= 3)
				{
					alert("Enter atleaset 4 chars");
					return false;
				}
				
			}
			
			/*Email validation*/
			if(document.getElementById("email").value=="")
			{
				alert("Enter Email");
				return false;
			}
			else
			{
				var mail=document.getElementById("email").value;
				var re = /\S+@\S+\.\S+/;
				if(!re.test(mail))
				{
					alert("Enter Valid Email");
					return false;
				}
			}
			/*Passsword validation*/
			if(document.getElementById("pwd").value=="")
			{
				alert("Enter Password");
				return false;
			}
			if(document.getElementById("cpwd").value=="")
			{
				alert("Enter Confirm Password");
				return false;
			}
			if(document.getElementById("pwd").value != document.getElementById("cpwd").value)
			{
				alert("Passwords does not matched");
				return false;
			}
			/*Mobile Validation*/
			if(document.getElementById("mobile").value=="")
			{
				alert("Enter Mobile");
				return false;
			}
			else
			{
				var mob=document.getElementById("mobile").value;
				var pat=/^[0]?[789]\d{9}$/;
				if(!pat.test(mob))
				{
					alert("Enter a 10 digit valid mobile number");
					return false;
				}
			}
			//gender validation
			if(!(document.getElementsByName("gender")[0].checked || document.getElementsByName("gender")[1].checked))
			{
				alert("Select Gender");
				return false;
			}
			//checkbox validation
			if(!document.getElementById("terms").checked)
			{
				alert("Please accept terms and conditions");
				return false;
			}
		}
		</script>
		
	</body>
</html>
<?php ob_end_flush();?>