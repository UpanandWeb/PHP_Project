<?php ob_start();?>
<html>
	<head>
		<title>Forgot Passwrod</title>
		<style></style>
	</head>
	<body>
		<h1>Forgot Passwrod</h1>
		
		<?php 
		if(isset($_COOKIE['success']))
		{
			echo "<p>".$_COOKIE['success']."</p>";
		}
		if(isset($_COOKIE['error']))
		{
			echo "<p>".$_COOKIE['error']."</p>";
		}
		
		//collect the form data
		if(isset($_POST['submit']))
		{
			$email=$_POST['email'];
			//connect to DB
			$con=mysqli_connect("localhost","root","","7am");
			//verify the email available in db or not
			
			$result=mysqli_query($con,"select email,uniid,username from users where email='$email'");
			//if found,send reset password link else display error
			if(mysqli_num_rows($result)==1)
			{
				$row=mysqli_fetch_assoc($result);
				$to=$email;
				$subject="Reset Password link-GoPHP";
				$message="Hi ".$row['username'].",<br><br>Your reset password request has been received.please click the below link to reset your password<br><br><a href='http://localhost:100/7am/resetpwd.php?uid=".$row['uniid']."'>Reset Password</a><br><br>Thanks<br>Team";
				$headers="Content-Type:text/html";
				
				if(mail($to,$subject,$message,$headers))
				{
					setcookie("success","Reset password link has been sent to your email, please check",time()+2);
					header("location:forgot.php");
				}
				else
				{
					setcookie("error","sorry unable to sent reset password link,contact admin",time()+2);
					header("location:forgot.php");
				}
			}
			else
			{
				echo "<p>Login Name not found in the system.</p>";
			}
			
			
		}
		
		
		
		
		?>
		
		<form method="POST" action="" onsubmit="return validate()">
			Enter Your Email:<input type="text" name="email" id="email"><br>
			<br>
			<input type="submit" name="submit" value="Submit">
		</form>
		<script>
			function validate()
			{
				if(document.getElementById("email").value=="")
				{
					alert("Enter Email");
					return false;
				}
				else
				{
					var mail=document.getElementById("email").value;
					var re = /\S+@\S+\.\S+/;
					if(!re.test(mail))
					{
						alert("Enter Valid Email");
						return false;
					}
				}
			}
		</script>
	</body>
</html>
<?php ob_end_flush();?>