<html>
	<head>
		<title>Dependency Dropdown by using AJAX</title>
	</head>
	<body>
		<h1>Dependency Dropdown AJAX</h1>
		
		<?php 
		$con=mysqli_connect("localhost","root","","7am");
		$result=mysqli_query($con,"select distinct state from states order by state ASC");
		?>
		
		<form method="POST" action="">
			Select State:
			<select id="state" name="state" onchange="getAllDistricts(this.value)">
				<option value="">--Select State--</option>
				<?php 
				while($row=mysqli_fetch_assoc($result))
				{
					?>
					<option value="<?php echo $row['state']?>"><?php echo $row['state']?></option>
					<?php
				}
				?>
				
			</select>
			Select District
			<select id="district">
				<option value="">--select district--</option>
			</select>
			
		</form>
		
		<script>
		function getAllDistricts(val)
		{
			//1.CREATE AJAX OBJECT
			var obj;
			if(window.XMLHttpRequest)
			{
				obj=new XMLHttpRequest();
			}
			else
			{
				obj=new ActiveXObject('Microsoft.XMLHTTP');
			}
			//2.SENDING REQUEST SERVER
			obj.open("GET","getdist.php?key="+val,true);
			obj.send();
			//3.HANDLING RESPONSE FROM SERVER
			obj.onreadystatechange=function(){
				if(obj.readyState==4 && obj.status==200)
				{
					document.getElementById("district").innerHTML=obj.responseText;
				}
			}
		}
		</script>
		
	</body>
</html>