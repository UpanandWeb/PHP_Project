<?php 
date_default_timezone_set("Asia/Kolkata");
echo date("l",strtotime("07-08-1995"));//Monday

//echo time();//1580442706


//echo date_default_timezone_get();
//date_default_timezone_set("Australia/Sydney");


//echo date("h:i:s A");

//echo date("l, dS F Y h:iA");
//echo date("l dS M Y");
//echo date("Y-m-d");



?>

