<?php

/*$color="yellow";
switch($color)
{
	case "red":
	echo "This is $color";
	break;
	
	case "green":
	echo "this is $color";
	break;
	
	default:
	echo "Nothing matched";
}


trenary operator:
=================
(condition) ? trueblock : falseblock;
*/
$x=(10>5) ? "Okay" : "Sorry";
echo $x;






/*$m=48;
if($m>=90)
{
	echo "Grade A";
}
elseif($m>=80)
{
	echo "Grade B";
}
elseif($m>=70)
{
	echo "Grade C";
}
elseif($m>=60)
{
	echo "Grade D";
}
else
{
	echo "FAIL";
}
*/

/*if(true && true && false)
{
	echo "Okay";
}	
*/




/*if(0==0)
{ 
	echo "Welcome";
}
*/


/*
$x=100;
$x=200;
$x=10;
echo $x;
*/

/*
$x='hello';
$y=100;
echo $x+$y;//error
*/






/*$x=100;
$y=true;
$z=$x*$y;
echo $z;//100

$x=100;
$y=false;
$z=$x*$y;
echo $z;//0
*/

/*$status=false;
echo $status;//
*/

?>
