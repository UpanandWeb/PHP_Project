<?php 
//echo $_SERVER['DOCUMENT_ROOT'];
//echo $_SERVER['SCRIPT_FILENAME'];
//echo $_SERVER['SERVER_PORT'];
//echo $_SERVER['SERVER_PROTOCOL'];
//http://example.com

?>
