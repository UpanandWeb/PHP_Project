<?php 

header("Content-Disposition:attachment;filename=9am.zip");
readfile("9am.zip");


?>