<?php 
//0 1 1 2 3 5 8 13 21 34

for($i=1;$i<=10;$i++);

echo $i;


/*$i=1;
do
{
	echo $i."<br>";
	$i++;
}
while($i<=10);
*/

/*$i=1;
$f1=0;
$f2=1;
echo $f1." ".$f2." ";
while($i<=10)
{
	$f3=$f1+$f2;
	echo $f3." ";
	$f1=$f2;
	$f2=$f3;
	$i++;
}
*/






/*
$i=1;
while($i<=10)
{
	echo $i."<br>";
	$i++;
}*/




/*for($i=2;$i<=20;$i++)
{
	for($j=2;$j<$i;$j++)
	{
		if($i%$j==0)
		{
			break;
		}
	}
	if($i==$j)
	{
		echo $i."<br>";
	}
}
*/
/*
for($i=1;$i<=50;$i++)
{
	if($i%5==0)
	{
		echo $i."<br>";
	}
}
*/
/*for($j=2;$j<=20;$j++)
{
	$table=$j;
	for($i=1;$i<=10;$i++)
	{
		echo $table."*".$i."=".$table*$i."<br>";
	}
	echo "<br>=============<br>";
}
*/
/*$x=100;
$y=200;
$z=$x+$y;

echo 'The sum of ' .$x.' and ' .$y. ' is '.$z;
*/

?>