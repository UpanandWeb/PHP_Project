<?php 
$x=100;
unset($x);
echo $x;




?>