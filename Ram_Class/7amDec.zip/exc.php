<?php 
function connection()
{
	if(!@$db=mysqli_connect("localhost","root","eqweq","7am"))
	{
		throw new Exception("Please check your connection details");
	}
	return $db;
}

try{
	$con=connection();
	$res=mysqli_query($con,"select *from users");
	$row=mysqli_fetch_assoc($res);
	print_r($row);
}
catch(Exception $e) 
{
	echo $e->getMessage();
}
?>