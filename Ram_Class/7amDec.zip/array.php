<pre><?php 

$arr = array(array(1000,2000),10,20,30,array(1000,200),array("Ram","Sam"));
echo "<pre>";
sort($arr);
print_r($arr);

/*foreach($arr as $x)
{
	if(is_array($x))
	{
		foreach($x as $v)
		{
			echo $v."<br>";
		}
	}
	else
	{
		echo $x."<br>";
	}
}
*/


/*for($i=2;$i<=20;$i++)
{
	for($j=2;$j<$i;$j++)
	{
		if($i%$j==0)
		{
			break;
		}
	}
	if($i==$j)
	{
		echo $i."<br>";
	}
}*/


/*$arr=array(10,20,30,40,50);

echo end($arr);//50
echo prev($arr);//40
echo next($arr);//50
echo current($arr);//50
*/

//array_splice($arr,5,0,100);

//print_r($arr);






/*$fa=array_slice($arr,2);//from 2nd position,we can get all the elements
print_r($fa);

$fa=array_slice($arr,2,4);//from 2nd position,we can get only 4 elements
print_r($fa);
*/

/*
$arr=array(
	"name"=>"Ram",
	"city"=>"Hyd",
	"state"=>"TS",
);
$fa=array_flip($arr);
print_r($fa);
*/
//$arr=array(10,20,30,40,50);
//array_pop($arr);
//unset($arr[3]);
//print_r($arr);

/*
$Earr=array();
$Oarr=array();
for($i=2;$i<=10;$i++)
{
	if($i%2==0)
	{
		$Earr[]=$i;
	}
	else
	{
		$Oarr[]=$i;
	}
}
print_r($Earr);
print_r($Oarr);
*/
/*
$arr[]=20;
$arr[]=30;
$arr[]=40;
*/


/*$arr=array(10,20,30);
echo array_unshift($arr,50);//4
print_r($arr);
*/
/*
$a1=array(10,20,30,40,60);

shuffle($a1);
print_r($a1);
$a1=array(10,20);
$a2=array(200,300);

$a3=array();
array_push($a3,$a1);
array_push($a3,$a2);

print_r($a3);
*/


//echo array_key_exists(3,$a1);//1
//echo array_key_exists(10,$a1);//



//echo in_array(40,$a1);//1
//echo in_array(20,$a1);//1




/*$c=count($a1);
for($i=0;$i<$c;$i++)
{
	if($a1[$i]==20)
	{
		echo $a1[$i].' is at '.$i.' <br>';
	}
}
*/

//echo array_search(40,$a1);//3
//echo array_search(20,$a1);//1


/*$arr=array(
	"name"=>"Ram",
	"city"=>"Hyd",
	"state"=>"TS",
);
asort($arr);
print_r($arr);
*/

/*$arr=array(
	"name"=>"Ram",
	"city"=>"Hyd",
	"state"=>"TS",
);
natcasesort($arr);
print_r($arr);
*/

//echo array_sum($arr);//21.5
//


/*$arr=array(
	"name"=>"ram",
	"city"=>"Hyd",
	"state"=>"TS",
);
*/
/*$arr =array("ram","naresh",'ball');
echo krsort($arr);//1
print_r($arr);
*/



//echo sizeof($arr);
//echo count($arr,true);//8
//echo count($arr);//5


/*
foreach($arr as $k=>$v)
{
	echo $k."=".$v."<br>";
}*/

/*$arr=array();
$arr[17]=30;
$arr[]=40;
$arr[]=50;
$arr[19]=60;

print_r($arr);
*/
/*
$arr = array(
	"name"=>"Ram",
	"city"=>"Hyd",
	"address"=>array(
			"doorno"=>"27/D",
			"area"=>"Maithrivanam",
			"pincode"=>500038,
			"landmark"=>"Metro Station",
		),
	"state"=>"Ts",
);

echo $arr['address']['pincode'];
echo $arr['address']['landmark'];
*/

/*$arr=array(
	"NamE"=>"Ram",
	"city"=>"Hyd",
	"state"=>"TS",
);

print_r($arr);

*/

?>