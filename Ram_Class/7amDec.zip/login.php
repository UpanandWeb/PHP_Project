<?php 
session_start();
$con = mysqli_connect("localhost","root","","7am");
?>
<html>
	<head>
		<title>Login Here</title>
		<style></style>
	</head>
	<body>
		<h1>Login Now</h1>
		
		<?php 
		if(isset($_POST['login']))
		{
			$email = filterData($_POST['email']);
			$pwd = filterData($_POST['pwd']);
			//verify the data
			$result = mysqli_query($con,"select uniid,email,status,password from register where email='$email'");
			if(mysqli_num_rows($result)==1)
			{
				$row=mysqli_fetch_assoc($result);
				if(password_verify($pwd,$row['password']))
				{
					if($row['status']=="active")
					{
						$_SESSION['logintrue']=$row['uniid'];
						header("Location:home.php");
					}
					else
					{
						echo "<p>Please activate your Account</p>";
					}
				}
				else
				{
					echo "<p>Wrong password entered for the email</p>";
				}
			}
			else
			{
				echo "<p>Wrong email entered. please check</p>";
			}
			
		}
		function filterData($data)
		{
			return addslashes(strip_tags(trim($data)));
		}
		?>
		
		<form method="POST" action="" onsubmit="return loginValidate()">
			<table>
				<tr>
					<td>Email</td>
					<td><input type="text" name="email" id="email"></td>
				</tr>
				<tr>
					<td>Password</td>
					<td><input type="password" name="pwd" id="pwd"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" name="login" value="Login">
					<a href="">Forgot Password?</a>
					</td>
				</tr>
			</table>
		</form>
		<script>
			function loginValidate()
			{
				if(document.getElementById("email").value=="")
				{
					alert("Enter Email");
					return false;
				}
				else
				{
					var email = document.getElementById("email").value;
					var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
					
					if(!email.match(mailformat))
					{
						alert("Enter Valid Email");
						return false;
					}
				}
				if(document.getElementById("pwd").value=="")
				{
					alert("Enter Password");
					return false;
				}
			}
		</script>
	</body>
</html>