<?php 
$conn = mysqli_connect("localhost","root","","7am");

?>
<html>
	<head>
		<title>Users List</title>
	</head>
	<body>
		<h1>Users List</h1>
		
		<?php 
		$res=mysqli_query($conn,"select *from contact");
		$n=mysqli_num_rows($res);
		if($n>=1)
		{
			?>
		<table border=1>
			<tr>
				<th>Id</th>
				<th>Name</th>
				<th>Email</th>
				<th>Mobile</th>
				<th>Message</th>
			</tr>
			<?php 
				for($i=0;$i<$n;$i++)
				{
					$row=mysqli_fetch_row($res);
				?>
			<tr>
				<td><?php echo $row[0];?></td>
				<td><?php echo $row[1];?></td>
				<td><?php echo $row[2];?></td>
				<td><?php echo $row[3];?></td>
				<td><?php echo $row[4];?></td>
			</tr>
				<?php
				}
			?>
		</table>
			<?php
		}
		else
		{
			echo "<p>Sorry! No records found</p>";
		}
		?>
	</body>
</html>