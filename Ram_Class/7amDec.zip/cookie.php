<?php 
session_start();
$_SESSION['name']="Ram";
$_SESSION['city']="Hyd";
?>