<html>
	<head>
		<title>File Uploading</title>
	</head>
	<body>
		<h1>Upload Avatar</h1>
		<?php 
		if(isset($_POST['upload']))
		{
			$filename = $_FILES['image']['name'];
			$size = $_FILES['image']['size'];
			$ftype = $_FILES['image']['type'];
			$tmpname = $_FILES['image']['tmp_name'];
			$error = $_FILES['image']['error'];
			
			$validTypes=array(
				"image/png",
				"image/jpg",
				"image/jpeg",
				"image/gif",
			);
			$str=str_shuffle("abcdefghijklmnopqrstvuwxyz");
			$ext = substr($str,10,15);
			$newname=$ext."_".time()."_".$filename;
			
			if(in_array($ftype,$validTypes))
			{
				$status = move_uploaded_file($tmpname,"uploads/$newname");
				if($status==1)
				{
					echo "<p>File Uploaded Successfully</p>";
				}
				else
				{
					echo "<p>Sorry! Unable to upload file. Try again</p>";
				}
			}
			else
			{
				echo "Please upload a valid file(png,jpg,gif,jpeg)";
			}
		}
		?>
		<form method="POST" action="" enctype="multipart/form-data">
			Upload Image:<br>
			<input type="file" name="image"><br><br>
			<input type="submit" name="upload" value="Upload">
		</form>
	</body>
</html>