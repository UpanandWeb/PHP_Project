<?php //4.2 connect to Db
$con=mysqli_connect("localhost","root","","7am");
?>
<html>
	<head>
		<title>Register Here</title>
		<style>
		span[id*="_error"]
		{
			color:red;
		}
		</style>
	</head>
	<body>
		<h1>Register Here</h1>
		<?php 
		if(isset($_COOKIE['error']))
		{
			echo "<P>".$_COOKIE['error']."</p>";
		}
		if(isset($_COOKIE['success']))
		{
			echo "<P>".$_COOKIE['success']."</p>";
		}
		
		if(isset($_POST['register']))
		{
			//4.1 collect the form data
			$uname = (isset($_POST['uname']))?filterData($_POST['uname']):"";
			
			$email = (isset($_POST['email']))?filterData($_POST['email']):"";
			
			$pwd = (isset($_POST['pwd']))?filterData($_POST['pwd']):"";		
			
			$pwd=password_hash($pwd,PASSWORD_DEFAULT);
			
			$gender = (isset($_POST['gender']))?filterData($_POST['gender']):"";
			
			$mobile = (isset($_POST['mobile']))?filterData($_POST['mobile']):"";	
			
			$dob = (isset($_POST['dob']))?filterData($_POST['dob']):"";	
			
			$state = (isset($_POST['state']))?filterData($_POST['state']):"";	
			
			$terms = (isset($_POST['terms']))?filterData($_POST['terms']):"";	
			
			$courses = implode("#",$_POST['courses']);
			
			$ip=$_SERVER['REMOTE_ADDR'];
			
			$uniid = md5(str_shuffle($uname.$email.$state.time()));
			
			//4.3 insert data into table 
			
			
			
			mysqli_query($con,"insert into register(username,email,password,gender,mobile,dob,state,courses,terms,ip,uniid) values('$uname','$email','$pwd','$gender','$mobile','$dob','$state','$courses','$terms','$ip','$uniid')");
			
			
			
			if(mysqli_affected_rows($con)==1)
			{
				//4.4 send an email notification to the registered user
				$to = $email;
				$subject = "Account Activation Link";
				$message="Hi $uname,<br>Thanks, your account created successfully withus. Please click the below link to activate your account<br><br><a href='http://localhost:100/7am/activate.php?token=".$uniid."' target='_blank'>Activate Now</a><br><br>Thanks<br>Team";

				$headers = 'From: webmaster@example.com' . "\r\n" .'Content-Type:text/html';
				
				if(mail($to,$subject,$message,$headers))
				{
					setcookie("success","Account created successfully. Please activate your account",time()+2);
					header("Location:register.php");
				}else
				{
					setcookie("error","Account created successfully. Unable to Send activation link.Contact Admin",time()+2);
					header("Location:register.php");
				}
				
			}
			else
			{
				echo mysqli_error($con);
				echo mysqli_errno($con);
				echo "<P>Sorry! Unable to create an acocount. try again</p>";
			}


			
		}
		function filterData($data)
		{
			return addslashes(strip_tags(trim($data)));
		}
		?>
		
		
		<form  method="POST" action="" onsubmit="return registerValidate()">
			<table>
				<tr>
					<td>Username*</td>
					<td><input type="text" name="uname" id="uname" onkeyup="checkValue(this)">
						<span id="uname_error"></span>
					</td>
				</tr>
			
				<tr>
					<td>Email*</td>
					<td><input type="text" name="email" id="email"></td>
				</tr>
				<tr>
					<td>Password*</td>
					<td><input type="password" name="pwd" id="pwd"></td>
				</tr>
				<tr>
					<td>Confirm Password*</td>
					<td><input type="password" name="cpwd" id="cpwd"></td>
				</tr>
				<tr>
					<td>Gender*</td>
					<td>
						<input type="radio" name="gender" value="male">Male
						<input type="radio" name="gender" value="female">Female
					</td>
				</tr>
				<tr>
					<td>Mobile*</td>
					<td><input type="text" name="mobile" id="mobile"></td>
				</tr>
				
				<tr>
					<td>DOB*</td>
					<td><input type="text" name="dob" id="dob"></td>
				</tr>
				<tr>
					<td>State</td>
					<td>
					<select id="state" name="state">
						<option value="">--select state--</option>
						<option value="Telangana">Telangana</option>
						<option value="Maharastra">Maharastra</option>
					</select>
					</td>
				</tr>
				<tr>
					<td>Courses*</td>
					<td>
						<input type="checkbox" name="courses[]" value="php">PHP
						<input type="checkbox" name="courses[]" value="mysql">MySQL
						<input type="checkbox" name="courses[]" value="javascript">JavaScript
					</td>
				</tr>
				<tr>
					<td></td>
					<td><input type="checkbox" name="terms" id="terms" value="yes">Please accept terms and conditions</td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" name="register" value="Register"></td>
				</tr>
			</table>
		</form>
		
		<script>
		function registerValidate()
		{
			if(document.getElementById("uname").value=="")
			{
				alert("Enter Username");
				return false;
			}
			if(document.getElementById("email").value=="")
				{
					alert("Enter Email");
					return false;
				}
				else
				{
					var email = document.getElementById("email").value;
					var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
					
					if(!email.match(mailformat))
					{
						alert("Enter Valid Email");
						return false;
					}
				}
			if(document.getElementById("pwd").value=="")
			{
				alert("Enter Password");
				return false;
			}
			if(document.getElementById("cpwd").value=="")
			{
				alert("Enter Confirm Password");
				return false;
			}
			
			if(document.getElementById("pwd").value!=document.getElementById("cpwd").value)
			{
				alert("Passwords Does not matched");
				return false;
			}
		}
		
		
		
		</script>
		
	</body>
</html>
<?php 
mysqli_close($con);
?>
