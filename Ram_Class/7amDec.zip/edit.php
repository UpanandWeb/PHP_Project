<?php 
session_start();
include("connect.php");
if(isset($_SESSION['logintrue']))
{
	$uniid=$_SESSION['logintrue'];
	$result=mysqli_query($con,"select *from register where uniid='$uniid'");
	$row=mysqli_fetch_assoc($result);
	
	?>
	<html>
		<head>
			<title><?php echo $row['username'];?> | Edit Profile</title>
			<style>
				.mymenu li{
					list-style-type:none;
					display:inline-block;
					padding:6px;
				}
				.mymenu{
					background:#666;
				}
				.mymenu li a{
					text-decoration:none;
					color:#fff;
				}
			</style>
		</head>
		<body>
		<ul class="mymenu">
					<li><a href="home.php">Home</a></li>
					<li><a href="edit.php">Edit</a></li>
					<li><a href="avatar.php">Upload Avatar</a></li>
					<li><a href="change_pass.php">Change Password</a></li>
					<li><a href="logout.php">Logout</a></li>
				</ul>
			<h1>Edit Profile | <?php echo $row['username'];?></h1>
			
			<?php 
			function filterData($data)
			{
				return addslashes(strip_tags(trim($data)));
			}
			if(isset($_COOKIE['success']))
			{
				echo "<p>".$_COOKIE['success']."</p>";
			}
		if(isset($_POST['update']))
		{
			//4.1 collect the form data
			$uname = (isset($_POST['uname']))?filterData($_POST['uname']):"";
			
					
			$gender = (isset($_POST['gender']))?filterData($_POST['gender']):"";
			
			$mobile = (isset($_POST['mobile']))?filterData($_POST['mobile']):"";	
			
			$dob = (isset($_POST['dob']))?filterData($_POST['dob']):"";	
			
			$state = (isset($_POST['state']))?filterData($_POST['state']):"";	

			$courses = implode("#",$_POST['courses']);
			
			mysqli_query($con,"update register set username='$uname',mobile='$mobile',gender='$gender',dob='$dob',state='$state',courses='$courses' where uniid='$uniid'");
			if(mysqli_affected_rows($con)>0)
			{
				setcookie("success","Profile updated successfully",time()+2);
				header("Location:edit.php");
			}
			else
			{
				echo mysqli_error($con);
				echo "<p>Sorry! Unable to update try again</p>";
			}
			
		
		}
		
			?>
			
			<form  method="POST" action="" onsubmit="return registerValidate()">
			<table>
				<tr>
					<td>Username*</td>
					<td><input type="text" name="uname" id="uname" onkeyup="checkValue(this)" value="<?php echo $row['username'];?>">
						<span id="uname_error"></span>
					</td>
				</tr>

				
				<tr>
					<td>Gender*</td>
					<td>
						<input type="radio" name="gender" value="male" <?php if($row['gender']=="male") echo "checked";?>>Male
						<input type="radio" name="gender" value="female"  <?php if($row['gender']=="female") echo "checked";?>>Female
					</td>
				</tr>
				<tr>
					<td>Mobile*</td>
					<td><input type="text" name="mobile" id="mobile" value="<?php echo $row['mobile'];?>"></td>
				</tr>
				
				<tr>
					<td>DOB*</td>
					<td><input type="text" name="dob" id="dob" value="<?php echo $row['dob'];?>"></td>
				</tr>
				<tr>
					<td>State</td>
					<td>
					<select id="state" name="state">
						<option value="">--select state--</option>
						<option  value="Telangana"  <?php if($row['state']=="Telangana") echo "selected";?>> Telangana</option>
						<option  value="Maharastra" <?php if($row['state']=="Maharastra") echo "selected";?>>Maharastra</option>
					</select>
					</td>
				</tr>
				<tr>
					<td>Courses*</td>
					<td>
					
						<?php 
						$sub=explode("#",$row['courses']);
						
						?>
					
						<input type="checkbox" name="courses[]" <?php if(in_array("php",$sub))echo "checked";?>  value="php">PHP
						<input type="checkbox" name="courses[]" <?php if(in_array("mysql",$sub))echo "checked";?>  value="mysql">MySQL
						<input type="checkbox" name="courses[]" <?php if(in_array("javascript",$sub))echo "checked";?> value="javascript">JavaScript
					</td>
				</tr>
				
				<tr>
					<td></td>
					<td><input type="submit" name="update" value="Update"></td>
				</tr>
			</table>
		</form>
		<script>
		function registerValidate()
		{
			if(document.getElementById("uname").value=="")
			{
				alert("Enter Username");
				return false;
			}
		}
		
		
		
		</script>
		</body>
	</html>
	<?php
}
else
{
	header("location:login.php");
}
?>