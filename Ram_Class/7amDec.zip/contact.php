<html>
	<head>
		<title>Contact Here</title>
		<style>
			body{
				background:#efefef;
			}
		</style>
	</head>
	<body>
		<h1>Contact Here</h1>
		
		<?php 
		if(isset($_COOKIE['success']))
		{
			echo "<p>".$_COOKIE['success']."</p>";
		}
		
		
		//4th step
		if(isset($_POST['save']))
		{
			//4.1 collect the form data
			$name=$_POST['uname'];
			$mail=$_POST['email'];
			$mob=$_POST['mobile'];
			$msg=$_POST['msg'];
			//4.2 connect to DB
			$con=mysqli_connect("localhost","root","","7am");
			//4.3 insert data into DB table
			mysqli_query($con,"insert into contact values('','$name','$mail','$mob','$msg')");
			
			if(mysqli_affected_rows($con)==1)
			{
				setcookie("success","Thanks, We will get back you soon",time()+2);
				header("location:contact.php");
			}
			else
			{
				echo "<p>Sorry! Unable to process, try again</p>";
			}
		}
		?>
		<form method="POST" action="" onsubmit="return validate()">
			<table>
				<tr>
					<td>Name*</td>
					<td><input type="text" id="uname" name="uname"></td>
				</tr>
				<tr>
					<td>Email*</td>
					<td><input type="text" id="email" name="email"></td>
				</tr>
				<tr>
					<td>Mobile</td>
					<td><input type="text" id="mobile" name="mobile"></td>
				</tr>
				<tr>
					<td>Message</td>
					<td><textarea id="msg" name="msg"></textarea></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" name="save" value="Send"></td>
				</tr>
			</table>
		</form>
		<script>
			//3rd step
			function validate()
			{
				var name = document.getElementById("uname").value;
				var mail = document.getElementById("email").value;
				
				if(name=="")
				{
					alert("Enter Username");
					return false;
				}
				if(mail=="")
				{
					alert("Enter Email");
					return false;
				}
			}
		</script>
	</body>
</html>
<?php mysqli_close($con);?>