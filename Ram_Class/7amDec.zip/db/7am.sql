-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 14, 2019 at 09:40 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `7am`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `mobile`, `message`) VALUES
(1, 'Ram', 'ram@mail.com', 123213123, 'Hello'),
(2, 'Ramu', 'ramu@mail.com', 123213123, 'Hello'),
(3, 'hello', 'hello@gmail.com', 234523434, 'hello worlds'),
(4, 'test', 'test@mail.com', 123123, 'tester'),
(5, 'xyz', 'xyz@mail.com', 234242324, 'fsdfdsfsdfsdf'),
(6, 'naresh', 'naresh@mail.com', 453223423, 'hello how are you?'),
(7, 'naresh', 'naresh@mail.com', 453223423, 'hello how are you?'),
(8, 'ram@mail.com', 'hello hi', 0, '213123123'),
(9, 'ram', 'ram@mail.com', 234234, 'hello'),
(10, 'test', 'test@mail.com', 234234234, 'adsfasdas'),
(11, 'Rasm', 'rambabburi@gmail.com', 9767676767, 'qqwe'),
(12, 'Rasm', 'rambabburi@gmail.com', 9767676767, 'ASas'),
(13, 'Rasm', 'rambabburi@gmail.com', 9767676767, 'ASas'),
(14, 'Rasm', 'rambabburi@gmail.com', 9767676767, 'ASas'),
(15, 'Rasm', 'rambabburi@gmail.com', 9767676767, 'ASas'),
(16, 'Ramu', 'rambabburi@gmail.com', 9767676767, 'asdsad'),
(17, 'Rasm', 'rambabburi@gmail.com', 9767676767, 'retert');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `dob` date NOT NULL,
  `state` varchar(50) NOT NULL,
  `courses` varchar(150) NOT NULL,
  `terms` varchar(10) NOT NULL,
  `date_of_join` datetime NOT NULL DEFAULT current_timestamp(),
  `ip` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'inactive',
  `profile` varchar(250) NOT NULL,
  `uniid` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `username`, `email`, `password`, `gender`, `mobile`, `dob`, `state`, `courses`, `terms`, `date_of_join`, `ip`, `status`, `profile`, `uniid`) VALUES
(1, 'Rasm', 'rambabburi@gmail.com', '$2y$10$BWq6V5QKReZuCFzrpJTVNesUzcKH7XTfflyaiTtxUqWokkibN5WvS', 'male', '9767676767', '1999-05-04', 'Telangana', 'php#mysql#javascript', 'yes', '2019-12-14 12:58:07', '::1', 'inactive', '', '145eb33793cd6bdca14d10574cca7c07'),
(2, 'Ramu', 'nit@mail.com', '$2y$10$p/d/jlLGSUeItayOXP41NuwDg.VitFPtGd94NEJcWbEhDIOd0n1SG', 'male', '9767676767', '0000-00-00', 'Telangana', 'php', 'yes', '2019-12-14 13:04:13', '::1', 'inactive', '', 'e4e5ec116d8dc523805b85d12c2a3d0c'),
(3, 'hello', 'hello@mail.com', '$2y$10$fBpWVz5YYOa3IrTqxwndkODd940B9OKKw4INdCrnWUVLzApIDyAmK', 'male', '9767676767', '1999-05-04', 'Telangana', 'php', 'yes', '2019-12-14 14:42:47', '::1', 'active', '', '286c2f1a10047a50d218b61492412d2e'),
(4, 'siav', 'siva@mail.com', '$2y$10$FloCUfnze9DUa/Xj3HC9ZOSY2LpTOhqafHP8ESbJNMiedjq6y33J6', 'male', '6767676767', '1999-05-04', 'Telangana', 'php', 'yes', '2019-12-14 15:00:46', '::1', 'inactive', '', 'c6b6b65776a87a61057308a89f052213');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
