<?php 
$x=100;
$y=200;
function add()
{	
	//$z=$x+$y;
	$z=$GLOBALS['x'] + $GLOBALS['y'];
	echo $z;
}
add();


?>