<?php 
session_start();
session_unset();
session_destroy();


//$city="xyz";
//echo $_COOKIE[$city];



//$x=100;
//var_dump($x);
////////////
//$name="ram";
//var_dump($name);
////////////
//
//$price=100.25;
//var_dump($price);


/*$arr=array(10,20,30);
print_r($arr);
echo $arr;//error
print $arr;//error
*/






?>
