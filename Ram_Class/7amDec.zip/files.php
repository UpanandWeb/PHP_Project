<?php 

$fp=opendir("images");
while($file=readdir($fp))
{
	if(!($file=="." || $file==".."))
	{
		$ext=substr($file,strpos($file,"."));
		if($ext==".jpg" || $ext==".png" || $ext==".gif")
		{
			echo "<img src='images/$file' height='100' width='100'>";
		}
	}
}


/*
$folder = "css";
if(file_exists($folder))
{
	rmdir($folder);
	echo $folder." is deleted...";
}
else
{
	
	echo $folder ." is not exists...";
}
*/
//Directory Handling Functions


//is_uploaded_file()
//move_uploaded_file()


/*
$file="ram.txt";
if(file_exists($file))
{
	unlink($file);
	echo $file." is deleted...";
}
else
{
	echo $file." is not avaliable";
}
*/
//echo file_exists("hi.txt");//1
//echo unlink("hi.txt");

/*
$data=file_get_contents("ram.txt");
echo htmlspecialchars_decode($data);
*/
/*
$tag="<p><b>Note:</b>This is PHP class</p>";
$x=htmlspecialchars($tag);
echo file_put_contents("ram.txt",$x);
*/
/*
echo file_get_contents("hi.txt");

echo file_get_contents("http://gophp.in");
echo file_get_contents("php://input");
*/

//echo file_put_contents("ram.txt","Welcome ram");


//echo readfile("hi.txt");

/*$time=filemtime("hi.txt");
echo date("Y-m-d h:i:s a",$time);
*/

/*$fp=fopen("hi.txt","r");
while($line=fgetss($fp))
{
	echo $line."<br>";
}
*/



//echo fread($fp,1000);

?>
