<?php 
session_start();
include("connect.php");
if(isset($_SESSION['logintrue']))
{
	$uniid = $_SESSION['logintrue'];
	
	$res = mysqli_query($con,"select *from register where uniid='$uniid'");
	
	$row=mysqli_fetch_assoc($res);
	
	
	?>
		<html>
			<head>
				<title>Welcome to <?php echo $row['username']; ?></title>
				<style>
					.mymenu li{
						list-style-type:none;
						display:inline-block;
						padding:6px;
					}
					.mymenu{
						background:#666;
					}
					.mymenu li a{
						text-decoration:none;
						color:#fff;
					}
				</style>
			</head>
			<body>
				
				<ul class="mymenu">
					<li><a href="home.php">Home</a></li>
					<li><a href="edit.php">Edit</a></li>
					<li><a href="avatar.php">Upload Avatar</a></li>
					<li><a href="change_pass.php">Change Password</a></li>
					<li><a href="logout.php">Logout</a></li>
				</ul>
			
				<h1>
				<?php 
				if($row['profile']=="")
				{
					?>
					<img src="images/avatar.jpg" height="25" width="25">
					<?php
				}
				else
				{
					?>
					<img src="profiles/<?php echo $row['profile']?>" height="25" width="25">
					<?php
				}
				?>
				
				
				Welcome to <?php echo $row['username']; ?></h1>
				<table border=1>
					<tr>
						<td>Id</td>
						<td><?php echo $row['id']; ?></td>
					</tr>
					<tr>
						<td>Name</td>
						<td><?php echo $row['username'];?></td>
					</tr>
					<tr>
						<td>Email</td>
						<td><?php echo $row['email'];?></td>
					</tr>
					<tr>
						<td>Mobile</td>
						<td><?php echo $row['mobile'];?></td>
					</tr>
					<tr>
						<td>Gender</td>
						<td><?php echo $row['gender'];?></td>
					</tr>
					<tr>
						<td>DOB</td>
						<td><?php echo $row['dob'];?></td>
					</tr>
					<tr>
						<td>State</td>
						<td><?php echo $row['state'];?></td>
					</tr>
					<tr>
						<td>Courses</td>
						<td><?php echo str_replace("#",",",$row['courses']);?></td>
					</tr>
					<tr>
						<td>Date of Join</td>
						<td><?php echo date("l, jS M Y",strtotime($row['date_of_join']));?></td>
					</tr>
					
				</table>
			</body>
		</html>
	<?php
}
else
{
	header("Location:login.php");
}

?>