<?php 

$data=file_get_contents("https://jsonplaceholder.typicode.com/todos/2");

$data=json_decode($data);
echo "<pre>";
print_r($data);

//reading data from an url
/*$data=file_get_contents("http://example.com/data.aspx");
$obj=json_decode($data);

//connect to DB
//Save to DB
*/
//get posted data from .java
//$data=file_get_contents("php://input");
//$obj=json_decode($data);

?>

