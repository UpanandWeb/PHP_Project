<?php 
	header("Content-Disposition:attachment;filename=project.zip");
	readfile("example.com/file.zip");
?>

