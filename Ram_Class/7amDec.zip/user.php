<html>
	<head>
		<title>User add form</title>
	</head>
	<body>
		<h1>User Add Form</h1>
		<?php
		if(count($_POST)>0)
		{
			$name=$_POST['uname'];
			$mail=$_POST['email'];
			var_dump($name);
			var_dump($mail);
			
			//Db
			//Insert
		}
		?>
		
		<form method="POST" action="">
			Username:<br>
			<input type="text" name="uname"><br><br>
			Email:<br>
			<input type="text" name="email"><br><br>
			<input type="submit" value="Add">
			
		</form>
	</body>
</html>