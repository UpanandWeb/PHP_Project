<?php 
//Looping Statements




/*$i=0;
while($i<=10)
{
	echo $i."<br>";
	$i=$i+2;
}
*/
/*initilization;
while(condition)
{
	//some statements
	inc|dec;
}
*/




/*$str="Welcome";
$i=0;
for(;@$str[$i]!="";)
{
	$i++;
}
echo $i;
*/



/*for($j=2;$j<=20;$j++)
{
	$table=$j;
	for($i=1;$i<=10;$i++)
	{
		echo $table."*".$i."=".$table*$i."<br>";
	}
}
*/

/*
for($i=1;$i<=10;$i++)
{
	if($i%5==0)
	{
		echo $i;
	}
}
*/
/*for($i=1;$i<=10;$i=$i+2)
{
	echo $i."<br>";
}
*/


/*
for($i=1;$i<=10;$i++)
{
	if($i%2==0)//1
	{
		echo $i."<br>";
	}
}
*/

//10 to 1
/*for($i=10;$i>=1;$i--)
{
	echo $i."<br>";
}
*/
/*
for($i=1;$i<=10;$i++)
{
	echo $i."<br>";
	
}*/

?>