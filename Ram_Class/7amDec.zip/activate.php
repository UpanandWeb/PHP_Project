<?php 
$con=mysqli_connect("localhost","root","","7am");
if(isset($_GET['token']))
{
	$id = filterData($_GET['token']);
	$result=mysqli_query($con,"select uniid,status from register where uniid='$id'");
	
	if(mysqli_num_rows($result)==1)
	{
		$row=mysqli_fetch_assoc($result);
		if($row['status']=="inactive")
		{
			mysqli_query($con,"update register set status='active' where uniid='$id'");
			if(mysqli_affected_rows($con)>0)
			{
				echo "<p>Account Activated Successfully</p>";
			}
		}
		else
		{
			echo "<P>Your account is already activated</p>";
		}
	}
	else
	{
		echo "<p>Sorry! Unable to locate your account</p>";
	}
	
}
else
{
	exit("Sorry! Wrong");
}


function filterData($data)
{
	return addslashes(strip_tags(trim($data)));
}
mysqli_close($con);
?>