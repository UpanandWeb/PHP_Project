<pre><?php 



/*$pass = "cmFtQDEyMzQ=";
echo base64_decode($pass);
*/



/*
$arr=array(10,20,30,40,50);
echo implode("@",$arr);
*/

/*$str="###10###20###30###40###50###";
$arr = explode("###",$str);
print_r($arr);
*/
/*
$str="this is java class.java is good";
echo str_replace("java","php",$str);

echo "<br>";

echo str_ireplace("JaVA","php",$str);
*/

/*
htmlspecialchars()
htmlspecialchars_decode()
*/
/*$name = "Ram\'s profile";
echo "Welcome to ".stripslashes($name);
*/


/*$name = "<h1 style='color:red'>Ram Babburi</h1>";
echo strip_tags($name);
*/


//$str="12345678900987654321456982317";
//echo substr(str_shuffle($str),16,4);


/*$image="php.jpg";
$pos = strpos($image,".");
echo substr($image,$pos+1);
*/
/*$str = "GNU General Public License as published by the Free Software";

echo substr($str,10);
//we can get all the string from 10th position
echo substr($str,0,20);
//we can get all the string from 0th position to 20 chracters
*/
//echo stripos($email,"A");

//$str="raM BaBBurI";
//echo ucwords(strtolower($str));


/*$name="Ram";
$str = <<<'XYZ'
		welcome to $name
		<h1>Welcome to php</h2>
		
	XYZ;
	
echo $str;
*/
?>