<?php 
//ECHO $_SERVER['DOCUMENT_ROOT'];
//print_r($_SERVER);

$x=200;
$y=300;
function add()
{
	global $x,$y,$z;
	$z=$x+$y;
}
add();
echo $z;
?>
