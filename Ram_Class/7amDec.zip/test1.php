<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<input type="text" id="aadhar" name="">
<input type="submit" value="submit" onclick="getData()">
<script>

function getData()
{
	var num = $("#aadhar").val();
	$.ajax({
		url:'http://npiregistry.cms.hhs.gov.api/?number='+num,
		method:'GET',
		success:function(res){
			console.log(res)
			//convert json data into object
			var data  = JSON.parse(res);
			console.log(data);
			//console.log(data.fname);
			//console.log(data.mobile);
			
		}
	});
}
</script>