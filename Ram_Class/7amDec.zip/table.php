<html>
	<head>
		<title>Print All Tables</title>
		<style>
			.table{
				display:inline-block;
				border:2px solid #d4d4d4;
				margin:2px;
				padding:5px;
			}
		</style>
	</head>
	<body>
		<h1>Print All Tables</h1>
		<div class="tables">
		<?php 
			for($j=2;$j<=20;$j++)
			{
				$table=$j;
				echo "<div class='table'>";
				for($i=1;$i<=10;$i++)
				{
					echo $table."*".$i."=".$table*$i."<br>";
				}
				echo "</div>";
			}
		?>
		</div>
	</body>
</html>