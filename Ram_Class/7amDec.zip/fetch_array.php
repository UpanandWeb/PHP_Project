<?php 
$con=mysqli_connect("localhost","root","","7am");
?>
<html>
	<head>
		<title>Users data</title>
		<style>
		table{
			border-collapse:collapse;
		}
		table tr td{
			padding:10px;
		}
		table tr:nth-child(odd)
		{
			background:#d4d4d4;
		}
		table tr:nth-child(even)
		{
			background:#efefef;
		}
		table tr:first-child{
			background:green;
		}
		th{color:#fff;}
		.error{
			border:1px solid #a40000;
			padding:5px 10px;
			color:#a40000;
		}
		</style>
	</head>
	<body>
		<h1>Users data</h1>
		
		<?php 
		$result=mysqli_query($con,"select *from contact");
		if(mysqli_num_rows($result)>0)
		{
			?>
			<table border=1>
			<tr>
				<th>Id</th>
				<th>Name</th>
				<th>Email</th>
				<th>Mobile</th>
				<th>Message</th>
			</tr>
			<?php 
			while($row=mysqli_fetch_array($result))
			{
				?>
			<tr>
				<td><?php echo $row['id']?></td>
				<td><?php echo $row['name']?></td>
				<td><?php echo $row[2]?></td>
				<td><?php echo $row[3]?></td>
				<td><?php echo $row['message']?></td>
				
			</tr>
				<?php
			}
			
			
			?>
			
		</table>
			<?php
		}
		else
		{
			echo "<p class='error'>Sorry! No Records Found</p>";
		}
		?>

	</body>
</html>