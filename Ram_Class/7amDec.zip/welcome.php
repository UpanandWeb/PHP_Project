
<html>
	<head>
		<title><?php echo "Test";?></title>
	</head>
	<body>
		<h1><?php echo "Welcome Ram";?></h1>
	</body>
</html>

