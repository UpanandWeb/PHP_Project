<pre><?php 
print_r($_REQUEST);

/*$mail= $_REQUEST['email'];
$pass=$_REQUEST['pwd'];
$name=$_REQUEST['username'];
*/
/*$h=implode("#",$_POST['hobbies']);
echo $h;
*/



//connect to DB
//Insert data into DB

/*print_r(ET);
$mail= $_GET['email'];
$pass=$_GET['pwd'];
$name=$_GET['username'];

echo $mail,$pass,$name;
*/
//connect to DB
//Insert data into DB

?>
