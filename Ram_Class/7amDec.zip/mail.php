<?php

$to ="rambabburi@gmail.com";

$subject="Activation link";

$message="Hi Ram,<br>Thanks for creating an account withus <a href=''>Welkcomne</a>";

$additional = "Content-Type:text/html";

if(mail($to,$subject,$message,$additional))
{
	echo "<p>Mail sent Successfully</p>";
}
else
{
	echo "<p>Sorry!</p>";
}

?>