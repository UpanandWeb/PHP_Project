<?php



$x = (((10<7) ? "Yes" : "No"))&& ((7<10) ? "Yes" : "No")) ;
echo $x;//Yes

$y=200;
$z = (isset($y)) ? "Set" : "Not Set";
echo $z;//Set

 

/*$favcolor = "blue";
switch ($favcolor) {
    case "red":
        if(0)
		{
			echo "Welcome";
		}
		else
		{
			echo "Testing";
		}
        break;
    case "blue":
        echo "Your favorite color is blue!";
        break;
    case "green":
        echo "Your favorite color is green!";
        break;
    default:
        echo "Your favorite color is neither red, blue, nor green!";
}*/
?>