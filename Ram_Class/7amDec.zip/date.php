<?php 
date_default_timezone_set("Asia/Kolkata");

$dob = "13-06-1995";
echo date("l",strtotime($dob));


/*echo date("l, Y-M-d h:i A",strtotime("1day 2weeks -2 years"));

*/


//echo date("l,Y-m-d",1564908618);

//echo date("l,Y-m-d",time());





//1970 jan 1st midnight to till today

//27-Nov-2019

//echo date("d-M-Y");
//Wednesday, 27 Nov,2019

//echo date("l, dS F, Y");

//date_default_timezone_set("Asia/Kolkata");
//date_default_timezone_set("Pacific/Auckland");
//date_default_timezone_set("Asia/Colombo");
//date_default_timezone_set("Europe/London");
//date_default_timezone_set("America/new_york");


//echo date("l, jS M Y g:i:s A");


?>

