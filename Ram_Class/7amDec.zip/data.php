<?php 
/*$name="Ram Babburi";
echo "<input type='' name='uname' value='$name'>";
*/
//echo '<input type="" name="uname" value="'.$name.'">';



/*$x=100;
$y=200;
$z=$x+$y;

echo 'you have to pay rs.'.$z.'/- Ram';

echo 'the sum of ' .$x.' and ' .$y. ' is: '.$z;
*/


//echo "the sum of $x and $y is: $z";

?>